#include"Arduino.h"
#include <stdio.h>
#include <Servo.h>
#include <string.h>

int model;
int angle;//舵机角度
extern Servo servo[4][3];
int Angle[4][3];//舵机角度矩阵

void stand()
{
  for (int i = 0; i < 4; i++){
    for (int j =0; j < 3; j++){
      if (j == 0){
        Angle[i][j] = 45;
      }else if(j ==1 ){
        if (i == 0 or i == 2){
          Angle[i][j] = 110;
        }else{Angle[i][j] = 70;}
      }else if (j == 2 ){
        if (i == 0 or i == 2){
          Angle[i][j] = 30;
        }else{Angle[i][j] = 0                                        ; }
      }
    }
  }
  Angle[2][0] = 30;
}

void servo_service()
{
  for (int i = 0; i < 4; i++){
    for (int j =0; j < 3; j++){
      angle = Angle[i][j];
      servo[i][j].write(angle);
    }
  }
}
void servo_init()
{
  if (model == 1){
    for(int i = 0; i < 4; i ++)
    {
      for (int j = 0; j < 3; j++)
      {
        if (j == 1){
          servo[i][j].write(90);  
        }else if (i == 0 and j == 0 or i == 2 and j == 0) {
          servo[i][j].write(0); 
        }else{
          servo[i][j].write(0);  
        }
      }
    }
  }else if(model == 2){
    for(int i = 0; i < 4; i ++)
    {
      for (int j = 0; j < 3; j++)
      {
        if (j == 1){
          servo[i][j].write(0);  
        }else {
          servo[i][j].write(0);  
        }
      }
    }
  }
}
