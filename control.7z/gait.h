#ifndef __GAIT_H__
#define __GAIT_H__


extern int model;//1表示蜘蛛行走模式，2表示狗行走方式，3.。。、。。
extern int angle;
extern int Angle[4][3];

void servo_init();
void stand();
void servo_service(); //定时器开关回调函数


#endif
